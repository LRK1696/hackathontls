var firebaseConfig = {
            apiKey: "AIzaSyBLMrcIL2PC3gv59M8nG4eX9IbOT8FX5SI",
            authDomain: "hackathontls.firebaseapp.com",
            databaseURL: "https://hackathontls.firebaseio.com",
            projectId: "hackathontls",
            storageBucket: "hackathontls.appspot.com",
            messagingSenderId: "345440720165",
            appId: "1:345440720165:web:4f9f5e90d2ba09e8c1b6cc"
          };
          // Initialize Firebase
          firebase.initializeApp(firebaseConfig);